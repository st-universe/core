<?php

	$bphases = 0;

	$thin = 711;
	$thick = 712;
		
	$density = 40;
	$degradation = 2;
	$fragmentation = 200;
	$invert = 0;
	$isthick = 0;
		
	$bphase[$bphases][mode] = "normal";
	$bphase[$bphases][description] = "Asteroid inner";
	$bphase[$bphases][num] = 0;
	$bphase[$bphases][from] = 0;
	$bphase[$bphases][to]   = 0;
	$bphase[$bphases][adjacent] = 0;
	$bphase[$bphases][noadjacent] = 0;
	$bphase[$bphases][noadjacentlimit] = 0;	
	$bphase[$bphases][fragmentation] = 20;				
	$bphases++;
			
	$bphase[$bphases][mode] = "normal";
	$bphase[$bphases][description] = "Asteroid inner";
	$bphase[$bphases][num] = 0;
	$bphase[$bphases][from] = 0;
	$bphase[$bphases][to]   = 0;
	$bphase[$bphases][adjacent] = 0;
	$bphase[$bphases][noadjacent] = 0;
	$bphase[$bphases][noadjacentlimit] = 0;	
	$bphase[$bphases][fragmentation] = 20;				
	$bphases++;
		
?>