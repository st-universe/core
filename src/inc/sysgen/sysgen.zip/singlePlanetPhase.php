<?php
	$spphase[0][mode] = "nocluster";
	$spphase[0][description] = "P";
	$spphase[0][num] = 1;
	$spphase[0][from] = array("0" => "101","1" => "103","2" => "105","3" => "111","4" => "113","5" => "115","6" => "107");
	$spphase[0][to]   = array("0" => "201","1" => "203","2" => "205","3" => "211","4" => "213","5" => "215","6" => "207");
	$spphase[0][adjacent] = 0;
	$spphase[0][noadjacent] = 0;
	$spphase[0][noadjacentlimit] = 0;	
	$spphase[0][fragmentation] = 1000;	
?>