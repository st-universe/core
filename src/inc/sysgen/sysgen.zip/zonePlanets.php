<?php
	
	if ($zones[$i][$j] == 1) $t = pdraw(array(111 => 45,115 => 45,105 => 10));
	if ($zones[$i][$j] == 2) $t = pdraw(array(101 => 40,103 => 35,105 => 25));
	if ($zones[$i][$j] == 3) $t = pdraw(array(113 => 60,107 => 40));
	if ($zones[$i][$j] == 4) $t = 113;
		
?>