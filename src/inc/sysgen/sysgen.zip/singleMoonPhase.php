<?php
	$smphase[0][mode] = "nocluster";
	$smphase[0][description] = "M";
	$smphase[0][num] = 1;
	$smphase[0][from] = array("0" => "403","1" => "430");
	$smphase[0][to]   = array("0" => "303","1" => "330");
	$smphase[0][adjacent] = 0;
	$smphase[0][noadjacent] = 0;
	$smphase[0][noadjacentlimit] = 0;	
	$smphase[0][fragmentation] = 1000;			
?>